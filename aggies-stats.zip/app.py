import os
import datetime as dt
from typing import Any, Dict, List, Optional

import requests
from flask import Flask, render_template, request


TEAM_ID = 245  # Texas A&M Aggies (ESPN team id)
ESPN_BASE = "https://site.api.espn.com/apis/site/v2/sports/football/college-football"


app = Flask(__name__)


def pretty_label(key: Optional[str]) -> str:
    if not key:
        return ""
    s = str(key)
    # Replace underscores with spaces
    s = s.replace("_", " ")
    # Insert spaces before camelCase capitals
    out = []
    prev_lower = False
    for ch in s:
        if ch.isupper() and prev_lower:
            out.append(" ")
        out.append(ch)
        prev_lower = ch.islower() or ch.isdigit()
    label = "".join(out)
    # Title case words except fully-uppercase tokens (e.g., YDS, TD)
    words = []
    for w in label.split():
        if len(w) <= 3 and w.isupper():
            words.append(w)
        else:
            words.append(w.capitalize())
    return " ".join(words)


# Expose as Jinja filter
app.jinja_env.filters["pretty"] = pretty_label


def fetch_json(url: str, params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    try:
        r = requests.get(url, params=params, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None


def get_schedule(team_id: int = TEAM_ID) -> List[Dict[str, Any]]:
    url = f"{ESPN_BASE}/teams/{team_id}/schedule"
    data = fetch_json(url) or {}
    events = data.get("events", [])
    return events


def event_is_final(event: Dict[str, Any]) -> bool:
    try:
        comp = event.get("competitions", [{}])[0]
        status = comp.get("status", {}).get("type", {}).get("name") or comp.get("status", {}).get("type", {}).get("state")
        return str(status).upper() in {"STATUS_FINAL", "POST"}
    except Exception:
        return False


def parse_competitors(event: Dict[str, Any]) -> Dict[str, Any]:
    comp = event.get("competitions", [{}])[0]
    competitors = comp.get("competitors", [])
    home = next((c for c in competitors if c.get("homeAway") == "home"), competitors[0] if competitors else {})
    away = next((c for c in competitors if c.get("homeAway") == "away"), competitors[1] if len(competitors) > 1 else {})
    return {"home": home, "away": away, "competition": comp}


def get_boxscore(event_id: str) -> Optional[Dict[str, Any]]:
    # Summary includes boxscore, leaders, etc.
    url = f"{ESPN_BASE}/summary"
    data = fetch_json(url, params={"event": event_id})
    return data


def safe_team_name(team_obj: Dict[str, Any]) -> str:
    return (
        team_obj.get("team", {}).get("displayName")
        or team_obj.get("team", {}).get("name")
        or team_obj.get("displayName")
        or team_obj.get("name")
        or "Unknown"
    )


def to_datetime(date_str: Optional[str]) -> Optional[dt.datetime]:
    if not date_str:
        return None
    try:
        return dt.datetime.fromisoformat(date_str.replace("Z", "+00:00"))
    except Exception:
        return None


def summarize_game(event: Dict[str, Any], selected_player_id: Optional[str] = None) -> Dict[str, Any]:
    comp_data = parse_competitors(event)
    comp = comp_data["competition"]
    home = comp_data["home"]
    away = comp_data["away"]
    eid = str(event.get("id") or comp.get("id"))

    date = to_datetime(event.get("date") or comp.get("date"))

    # Scores
    try:
        home_score = int(home.get("score", 0))
        away_score = int(away.get("score", 0))
    except Exception:
        home_score = int(home.get("score", {}).get("value", 0) or 0)
        away_score = int(away.get("score", {}).get("value", 0) or 0)

    # Which side is Texas A&M?
    def is_aggies(c: Dict[str, Any]) -> bool:
        t = c.get("team", {})
        return int(t.get("id", 0)) == TEAM_ID

    aggies_side = "home" if is_aggies(home) else "away"
    opp_side = "away" if aggies_side == "home" else "home"
    aggies_comp = home if aggies_side == "home" else away
    opp_comp = away if aggies_side == "home" else home

    aggies_name = safe_team_name(aggies_comp)
    opponent_name = safe_team_name(opp_comp)

    aggies_score = home_score if aggies_side == "home" else away_score
    opponent_score = away_score if aggies_side == "home" else home_score

    result = "W" if aggies_score > opponent_score else ("L" if aggies_score < opponent_score else "T")

    venue = (comp.get("venue") or {}).get("fullName") or (comp.get("venue") or {}).get("address", {}).get("city")

    # Fetch detailed stats
    box = get_boxscore(eid) or {}
    team_stats: List[Dict[str, Any]] = []
    aggies_players: List[Dict[str, Any]] = []
    selected_player_stats: List[Dict[str, Any]] = []
    if box:
        # Team stats
        try:
            bstats = (box.get("boxscore", {}) or {}).get("teams", [])
            for t in bstats:
                team_name = safe_team_name(t)
                stats = t.get("statistics", []) or t.get("stats", [])
                team_stats.append({
                    "team": team_name,
                    "stats": stats,
                })
        except Exception:
            pass

        # Players list (from boxscore players)
        try:
            players_groups = (box.get("boxscore", {}) or {}).get("players", [])
            # Find group for the Aggies team
            for grp in players_groups:
                # grp has keys: team, statistics[], displayOrder
                team = grp.get("team") or {}
                if int(team.get("id", 0)) != TEAM_ID:
                    continue
                # Aggregate athletes from each stat category
                seen = set()
                for cat in grp.get("statistics", []):
                    for a in cat.get("athletes", []):
                        ath = a.get("athlete") or {}
                        pid = str(ath.get("id"))
                        if pid and pid not in seen:
                            seen.add(pid)
                            aggies_players.append({
                                "id": pid,
                                "name": ath.get("displayName") or (str(ath.get("firstName","")) + " " + str(ath.get("lastName",""))).strip(),
                                "jersey": ath.get("jersey"),
                            })

                # If a selection is provided, compile that player's per-category stats
                if selected_player_id:
                    for cat in grp.get("statistics", []):
                        labels = cat.get("labels") or []
                        category = cat.get("name") or cat.get("text")
                        for a in cat.get("athletes", []):
                            ath = a.get("athlete") or {}
                            if str(ath.get("id")) == str(selected_player_id):
                                stats = a.get("stats", [])
                                items = []
                                for i, val in enumerate(stats):
                                    lab = labels[i] if i < len(labels) else f"Stat {i+1}"
                                    items.append({"label": lab, "value": val})
                                selected_player_stats.append({
                                    "category": pretty_label(category),
                                    "entries": items,
                                })
                break  # only Aggies group
        except Exception:
            pass

    # Leaders (optional)
    leaders = []
    try:
        lead_groups = (box.get("leaders") or {}).get("leaders", [])
        for g in lead_groups:
            cat = g.get("name") or g.get("displayName")
            items = []
            for l in g.get("leaders", []):
                athlete = (l.get("athlete") or {})
                items.append({
                    "name": athlete.get("displayName") or athlete.get("name"),
                    "team": safe_team_name(athlete.get("team") or {}),
                    "value": l.get("value") or l.get("displayValue") or "",
                })
            if items:
                leaders.append({"category": cat, "items": items})
    except Exception:
        pass

    return {
        "event_id": eid,
        "date": date,
        "venue": venue,
        "aggies_name": aggies_name,
        "opponent_name": opponent_name,
        "aggies_score": aggies_score,
        "opponent_score": opponent_score,
        "result": result,
        "team_stats": team_stats,
        "leaders": leaders,
        "aggies_players": aggies_players,
        "selected_player_stats": selected_player_stats,
    }


def get_recent_games(limit: int = 5, selected_player_id: Optional[str] = None) -> List[Dict[str, Any]]:
    events = get_schedule(TEAM_ID)
    finals = [e for e in events if event_is_final(e)]
    # Sort by date descending
    def key(e: Dict[str, Any]):
        d = to_datetime(e.get("date") or e.get("competitions", [{}])[0].get("date"))
        return d or dt.datetime.min

    finals.sort(key=key, reverse=True)
    games = [summarize_game(e, selected_player_id=selected_player_id) for e in finals[:limit]]
    return games


@app.route("/")
def index():
    n = request.args.get("n", default=5, type=int)
    player_id = request.args.get("player")
    games = get_recent_games(limit=max(1, min(n, 10)), selected_player_id=player_id)

    # Simple aggregate summary
    wins = sum(1 for g in games if g.get("result") == "W")
    losses = sum(1 for g in games if g.get("result") == "L")
    ties = sum(1 for g in games if g.get("result") == "T")
    pf = sum(int(g.get("aggies_score", 0) or 0) for g in games)
    pa = sum(int(g.get("opponent_score", 0) or 0) for g in games)
    count = len(games) or 1
    summary = {
        "games": len(games),
        "record": f"{wins}-{losses}{('-'+str(ties)) if ties else ''}",
        "avg_for": round(pf / count, 1),
        "avg_against": round(pa / count, 1),
        "avg_margin": round((pf - pa) / count, 1),
    }

    # Build player dropdown from all fetched games (Aggies only)
    player_map: Dict[str, Dict[str, Any]] = {}
    for g in games:
        for p in g.get("aggies_players", []) or []:
            player_map[p["id"]] = p
    players = sorted(player_map.values(), key=lambda x: (x.get("jersey") or "999", x.get("name") or ""))

    return render_template("index.html", games=games, summary=summary, players=players, selected_player_id=player_id)


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    debug = os.getenv("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug)
