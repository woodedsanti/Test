# Texas A&M Aggies – Recent Games Web App

Small Flask app that shows recent Texas A&M football games with team box score stats and optional per‑player stats pulled from public ESPN endpoints.

## Run Locally

- Python 3.10+
- Windows PowerShell example:

```
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000 (use `/?n=5` to change the number of games). Use the Player dropdown to view a specific player’s stat lines per game.

## Project Layout

- `app.py` – Flask server and ESPN fetchers
- `templates/` – HTML templates (Jinja2)
- `static/` – CSS styles
- `requirements.txt` – dependencies

## Notes

- Data comes from ESPN’s public College Football APIs; this project is unofficial and for personal/educational use.
- Player stats appear only when ESPN provides them in the game’s box score.

## Deploy

Any Python host that supports Flask will work. Example (Render/railway/etc.):
- Set a `PORT` env var if required by the host
- Start command: `python app.py`
